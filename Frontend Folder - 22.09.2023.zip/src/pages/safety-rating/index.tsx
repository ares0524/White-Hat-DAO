import { Fragment } from "react"

export const SafetyRating = () => {
    return (
        <Fragment>
            <h1 style={{color:'#346DA1'}}>Coming Soon</h1>
        </Fragment>
    )
}