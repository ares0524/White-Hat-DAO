import { Fragment } from "react"

export const BlogPost = () => {
    return (
        <Fragment>
            
        </Fragment>
    )
}